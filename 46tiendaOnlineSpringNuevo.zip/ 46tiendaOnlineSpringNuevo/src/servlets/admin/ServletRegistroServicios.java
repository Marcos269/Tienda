package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ServiciosDAO;
import daos.UsuariosDAO;
import modelo.Servicio;
import modelo.Usuario;


@WebServlet("/admin/ServletRegistroServicios")
public class ServletRegistroServicios extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//metodo que se ejecuta independientemente de que el 
		//servlet haya recibido una peticion tipo get/post u otra
		
		//aqui siempre se indica el name de cada input 
		//para poder recoger lo que haya puesto el usuario
		String nombre = request.getParameter("campoNombreSer");
		String descripcion = request.getParameter("campoDescripcion");
		String precio = request.getParameter("campoPrecioSer");
		double precioDouble = Double.parseDouble(precio);
		
		
		Servicio nuevo = new Servicio(nombre,descripcion,precioDouble);
		System.out.println("voy a registrar: " + nuevo);
		System.out.println(
		 "vamos a ver si somos capaces de recuperar una bean "
		 + "del contenedor de spring");
		WebApplicationContext contenedor = 
				ContextLoader.getCurrentWebApplicationContext();
		ServiciosDAO dao = contenedor.getBean(ServiciosDAO.class);
		dao.registrarServicio(nuevo);
		
		//si todo ha ido bien continuo la peticion
		//a registroOK.jsp
		RequestDispatcher rd = 
				getServletContext().getRequestDispatcher(
						"/admin/ServletListadoServicios");
		rd.forward(request, response);	
	}

}

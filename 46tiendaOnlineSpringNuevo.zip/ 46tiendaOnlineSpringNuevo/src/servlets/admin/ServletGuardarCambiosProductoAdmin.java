package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;
import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;
import daos.productosDAO;


@WebServlet("/admin/ServletGuardarCambiosProductoAdmin")
public class ServletGuardarCambiosProductoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nombre = request.getParameter("campoNombre");
		String grupo = request.getParameter("campoGrupo");
		String tipo= request.getParameter("campoTipo");
		String precio = request.getParameter("campoPrecio");
		double precioDouble = Double.parseDouble(precio);
		String id = request.getParameter("campoId");
		
		Producto productoAeditar= new Producto();
		productoAeditar.setNombre(nombre);
		productoAeditar.setGrupo(grupo);
		productoAeditar.setTipo(tipo);
		productoAeditar.setPrecio(precioDouble);
		productoAeditar.setId(Integer.parseInt(id));
		
		WebApplicationContext contenedor = 
				ContextLoader.getCurrentWebApplicationContext();
		 productosDAO dao = contenedor.getBean(productosDAO.class);
		dao.actualizarProducto(productoAeditar);
		
		RequestDispatcher rd = 
				getServletContext().getRequestDispatcher(
						"/admin/ServletListadoProductos");
		rd.forward(request, response);
		
		
	}

}

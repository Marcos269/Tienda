package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;


@WebServlet("/admin/ServletEditarUsuarioAdmin")
public class ServletEditarUsuarioAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idAeditar = request.getParameter("id");
		System.out.println("queremos editar este id :" + idAeditar);
		
				WebApplicationContext contenedor = 
						ContextLoader.getCurrentWebApplicationContext();
				UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
				
				String idPulsado = request.getParameter("id");
				Usuario usuario = dao.editarUsuarioPorId(Integer.parseInt(idPulsado));
				request.setAttribute("usuario", usuario);
				
				RequestDispatcher rd = 
						getServletContext().getRequestDispatcher(
								"/admin/editarUsuario.jsp");
				rd.forward(request, response);
	}

}

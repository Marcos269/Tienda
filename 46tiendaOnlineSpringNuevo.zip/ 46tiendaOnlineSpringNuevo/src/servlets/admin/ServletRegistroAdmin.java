package servlets.admin;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.productosDAO;
import modelo.Producto;

/**
 * Servlet implementation class ServletRegistroAdmin
 */
@WebServlet("/admin/ServletRegistroAdmin")
@MultipartConfig
public class ServletRegistroAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nombre = request.getParameter("campoNombre");
		String precio = request.getParameter("campoPrecio");
		String grupo = request.getParameter("campoGrupo");
		String tipo = request.getParameter("campoTipo");
		precio = precio.replace(",",".");
		double precioDouble = Double.parseDouble(precio);
		Producto nuevo = new Producto(nombre,precioDouble,grupo,tipo);		
		
		WebApplicationContext contenedor = 
				ContextLoader.getCurrentWebApplicationContext();
		// asi le pido al cotnenedor de spring que nos de la unica bean que tiene de una clase que omplemente el interfaz productos dao
		productosDAO dao = contenedor.getBean(productosDAO.class);
		int idGenerado = dao.registrarProducto(nuevo);
				
		String rutaArchivo = getServletContext().getRealPath("")+ "/"+"subidasImagenesDiscos";
		File carpeta = new File(rutaArchivo);
		if( ! carpeta.exists()){
			carpeta.mkdir();
		}
		
		Part campoImagen = request.getPart("campoImagen");
		campoImagen.write(rutaArchivo +"/"+ idGenerado + ".jpg");
				
		System.out.println("Archivo subido a la carpeta : " + rutaArchivo);
				
		RequestDispatcher rd = 
				getServletContext().getRequestDispatcher(
						"/admin/ServletListadoProductos");
		rd.forward(request, response);	
	}
}

package servlets.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;
import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;
import daos.productosDAO;


@WebServlet("/admin/ServletEditarProductoAdmin")
public class ServletEditarProductoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idAeditar = request.getParameter("id");
		System.out.println("queremos editar este id :" + idAeditar);
		
				WebApplicationContext contenedor = 
						ContextLoader.getCurrentWebApplicationContext();
				productosDAO dao = contenedor.getBean(productosDAO.class);
				
				String idPulsado = request.getParameter("id");
				Producto producto = dao.editarProdutoPorId(Integer.parseInt(idPulsado));
				request.setAttribute("producto", producto);
				
				RequestDispatcher rd = 
						getServletContext().getRequestDispatcher(
								"/admin/editarProducto.jsp");
				rd.forward(request, response);
	}

}

package filtros;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FiltroLogin implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain fc) throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		
		if(request.getParameter("passAdmin")!=null && request.getParameter("passAdmin").equals("1234")){
			//Se ha introducido la contrase�a correc
			request.getSession().setAttribute("admin","ok");
		}
		
		if(request.getSession().getAttribute("admin") != null && request.getSession().getAttribute("admin").equals("ok")){
			fc.doFilter(req, res);
		}else{
			RequestDispatcher rd = request.getRequestDispatcher("/admin/login.jsp");
			rd.forward(req, res);
			// end if
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}

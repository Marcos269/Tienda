package mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import modelo.CategoriaUsuario;
import modelo.Usuario;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

public class UsuariosMapper implements RowMapper<Usuario> {

	@Override
	public Usuario mapRow(ResultSet rs, int numeroFila) throws SQLException {
		Usuario u = new Usuario();
		u.setNombre(rs.getString("nombre"));
		u.setEmail(rs.getString("email"));
		u.setPass(rs.getString("pass"));
		u.setId(rs.getInt("id"));
		CategoriaUsuario cu = new CategoriaUsuario();
		cu.setNombre(rs.getString("nombre"));
		cu.setNombre(rs.getString("nombre_categoria"));
		u.setCategoriaUsuario(cu);
		
		
		return u;
	}

	

}

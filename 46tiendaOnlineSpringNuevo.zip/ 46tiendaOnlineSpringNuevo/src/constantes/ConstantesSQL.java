package constantes;

public class ConstantesSQL {

	public final static String SQL_SELECCION_ID_POR_EMAIL_PASS = 
		"select id from tabla_usuarios where email = ? and pass = ? ";
	
	public final static String SQL_SELECCION_ID_POR_EMAIL = 
			"select id from tabla_usuarios where email = ? ";
	
	public final static String SQL_SELECCION_USUARIOS = 
		"select * from tabla_usuarios order by id desc";
	
	public final static String SQL_SELECCION_PRODUCTOS = 
			"select * from discos order by id desc ";
	
	public final static String SQL_SELECCION_SERVICIOS = 
			"select * from servicios order by id desc ";
	
	public final static String SQL_SELECCION_CATEGORIAS = 
			"select * from categorias order by id desc ";
		
	public final static String SQL_BORRAR_USUARIO = 
			"delete  from tabla_usuarios where id = ? ";
	
	public final static String SQL_EDITAR_USUARIO = 
			"select * from tabla_usuarios where id = ?";
	
	public final static String SQL_BORRAR_PRODUCTO = 
			"delete  from discos where id = ? ";
	
	public final static String SQL_EDITAR_PRODUCTO = 
			"select * from discos where id = ?";
	public final static String SQL_ACTUALIZAR_PRODUCTO = 
			"update discos set nombre = ?,grupo = ? , tipo = ? , precio = ? where id = ?";
	
	public final static String SQL_ACTUALIZAR_USUARIO = 
			"update tabla_usuarios set nombre = ?,email = ? , " + "pass = ? where id = ?";
	
	public final static String SQL_SELECCION_USUARIOS_INICIO_CUANTOS = 
			"select * from tabla_usuarios order by id desc limit ?,?;";
	
	public final static String SQL_TOTAL_USUARIOS = 
			"select count(*) from tabla_usuarios";
	
	public final static String SQL_SELECCION_PRODUCTOS_INICIO_CUANTOS = 
			"select * from discos order by id desc limit ?,?;";
	
	public final static String SQL_TOTAL_PRODUCTOS = 
			"select count(*) from discos";
	
	public final static String SQL_SELECCION_USUARIOS_INICIO_CUANTOS_BUSQUEDA = 
			"select * from tabla_usuarios where nombre like ? order by id desc limit ?,?;";
	
	public final static String SQL_TOTAL_USUARIOS_BUSQUEDA = 
			"select count(*)  from tabla_usuarios where nombre like ?";
	
	public final static String SQL_SELECCION_CATEGORIAS_USUARIOS = 
			"select *  from categorias order by id desc";
	
	public final static String SQL_SELECCION_USUARIOS_INICIO_CUANTOS_BUSQUEDA_QUERY = 
			"SELECT tu.id,tu.nombre,tu.email,tu.pass,tcu.nombre as nombre_categoria FROM tabla_usuarios as tu,categorias as tcu where tu.idCategoriaUsuario = tcu.id and tu.nombre like ? order by tu.id desc limit ?,?;";
}

package ServletPruebas;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;

@WebServlet("/ServletRegistroCienUsuarios")
public class ServletRegistroCienUsuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		WebApplicationContext contenedor = ContextLoader
				.getCurrentWebApplicationContext();
		UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
		for (int i = 0; i < 100; i++) {
			Usuario u = new Usuario("luis"+i, i+"luis@gmail.com", "123");
			dao.registrarUsuario(u);
			System.out.println("registrado : " + u.toString());
		}// end for
		System.out.println("Hemos registrado 100 usuarios");
	} // end service
} // end class 

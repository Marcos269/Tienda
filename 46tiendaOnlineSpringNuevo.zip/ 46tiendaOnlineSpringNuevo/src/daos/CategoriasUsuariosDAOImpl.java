package daos;

import java.util.List;




import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import constantes.ConstantesSQL;
import modelo.CategoriaUsuario;

public class CategoriasUsuariosDAOImpl implements  CategoriasUsuariosDAO {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	
	
	public DataSource getDataSource() {
		return dataSource;
	}



	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	@Override
	public List<CategoriaUsuario> obtenerCategorias() {
		
		List<CategoriaUsuario> categoriaUsuarios = jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_CATEGORIAS_USUARIOS, new BeanPropertyRowMapper(CategoriaUsuario.class));
		
		return categoriaUsuarios;
	}
			
}	

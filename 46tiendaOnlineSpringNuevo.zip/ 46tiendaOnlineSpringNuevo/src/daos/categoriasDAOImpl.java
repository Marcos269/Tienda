package daos;

import java.util.HashMap;
import java.util.List;








import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Categoria;
import modelo.Producto;
import modelo.Servicio;

public class categoriasDAOImpl implements CategoriasDAO{
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.dataSource = dataSource;
		simpleInsert = new SimpleJdbcInsert(dataSource);
		simpleInsert.setTableName("categorias");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	@Override
	public void registrarCategoria(Categoria p) {
		// TODO Auto-generated method stub
		HashMap<String , Object> valores = new HashMap<String,Object>();
		valores.put("nombre",p.getNombre());
		valores.put("descripcion",p.getDescripcion());
		simpleInsert.execute(valores);
	}
	@Override
	public List<Categoria> obtenerCategorias() {
		String sql = ConstantesSQL.SQL_SELECCION_CATEGORIAS;
		List<Categoria> categorias = jdbcTemplate.query(sql,new BeanPropertyRowMapper(Categoria.class));
		return categorias;
	}
	

}

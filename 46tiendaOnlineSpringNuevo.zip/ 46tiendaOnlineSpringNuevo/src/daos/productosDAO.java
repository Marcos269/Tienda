package daos;

import java.util.List;

import modelo.Producto;
import modelo.Usuario;

public interface productosDAO {
		
	int registrarProducto(Producto p);
	List<Producto> obtenerProductos();
	
	void borrarProductoPorId(int  id);
	Producto editarProdutoPorId(int  id);
	void actualizarProducto(Producto u);
	
	List<Producto> obtenerProducto(int comienzo,int cuantos);
	int obtenerTotalproductos();
}

package daos;

import java.util.HashMap;
import java.util.List;










import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Producto;
import modelo.Usuario;

public class productosDAOImpl implements productosDAO{
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.dataSource = dataSource;
		simpleInsert = new SimpleJdbcInsert(dataSource);
		simpleInsert.setTableName("discos");
		simpleInsert.usingGeneratedKeyColumns("id");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	@Override
	public int registrarProducto(Producto p) {
		// TODO Auto-generated method stub
		HashMap<String , Object> valores = new HashMap<String,Object>();
		valores.put("nombre",p.getNombre());
		valores.put("grupo",p.getGrupo());
		valores.put("tipo",p.getTipo());
		valores.put("precio",p.getPrecio());
		
		int idGenerado = simpleInsert.executeAndReturnKey(valores).intValue();
		return idGenerado;
	}
	@Override
	public List<Producto> obtenerProductos() {
		String sql = ConstantesSQL.SQL_SELECCION_PRODUCTOS;
		List<Producto> productos = jdbcTemplate.query(sql,new BeanPropertyRowMapper(Producto.class));
		return productos;
	}
	@Override
	public void borrarProductoPorId(int id) {
		// TODO Auto-generated method stub
		jdbcTemplate.update(ConstantesSQL.SQL_BORRAR_PRODUCTO,id);
		
	}
	@Override
	public Producto editarProdutoPorId(int id) {
		// TODO Auto-generated method stub
		String valores[] = {String.valueOf(id)};
		Producto producto = (Producto) jdbcTemplate.queryForObject(ConstantesSQL.SQL_EDITAR_PRODUCTO,valores,new BeanPropertyRowMapper(Producto.class));
		
		return producto;
	}
	@Override
	public void actualizarProducto(Producto u) {
		// TODO Auto-generated method stub
		jdbcTemplate.update(ConstantesSQL.SQL_ACTUALIZAR_PRODUCTO,u.getNombre(),u.getGrupo(),u.getTipo(),u.getPrecio(),u.getId());
	}
	@Override
	public List<Producto> obtenerProducto(int comienzo, int cuantos) {
		// TODO Auto-generated method stub
		Integer [] valores = {comienzo,cuantos};
		List<Producto> productos = 
				jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_PRODUCTOS_INICIO_CUANTOS,valores,new BeanPropertyRowMapper(Producto.class));
		return productos;
	}
	@Override
	public int obtenerTotalproductos() {
		// TODO Auto-generated method stub
		int total = jdbcTemplate.queryForInt(ConstantesSQL.SQL_TOTAL_PRODUCTOS);
		return total;
	}
	
	

}

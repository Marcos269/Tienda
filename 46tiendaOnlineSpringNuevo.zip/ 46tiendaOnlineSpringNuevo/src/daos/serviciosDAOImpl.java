package daos;

import java.util.HashMap;
import java.util.List;







import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Producto;
import modelo.Servicio;

public class serviciosDAOImpl implements ServiciosDAO{
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.dataSource = dataSource;
		simpleInsert = new SimpleJdbcInsert(dataSource);
		simpleInsert.setTableName("servicios");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	@Override
	public void registrarServicio(Servicio p) {
		// TODO Auto-generated method stub
		HashMap<String , Object> valores = new HashMap<String,Object>();
		valores.put("nombre",p.getNombre());
		valores.put("descripcion",p.getDescripcion());
		valores.put("precio",p.getPrecio());
		simpleInsert.execute(valores);
	}
	@Override
	public List<Servicio> obtenerServicios() {
		String sql = ConstantesSQL.SQL_SELECCION_SERVICIOS;
		List<Servicio> servicios = jdbcTemplate.query(sql,new BeanPropertyRowMapper(Servicio.class));
		return servicios;
	}
	

}

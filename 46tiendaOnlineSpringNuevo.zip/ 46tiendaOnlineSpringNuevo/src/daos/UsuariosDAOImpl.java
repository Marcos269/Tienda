package daos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import mappers.UsuariosMapper;
import modelo.Usuario;

public class UsuariosDAOImpl implements UsuariosDAO{

	
	private DataSource elDataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	
	
	public DataSource getElDataSource() {
		return elDataSource;
	}

	//para que este DAO funcione tiene que recibir 
	//un datasource, cuando llegue preparo el 
	//simple insert 
	public void setElDataSource(DataSource elDataSource) {
		this.elDataSource = elDataSource;
		simpleInsert = new SimpleJdbcInsert(elDataSource);
		simpleInsert.setTableName("tabla_usuarios");
		simpleInsert.usingGeneratedKeyColumns("id");
		jdbcTemplate = new JdbcTemplate(elDataSource);
	}

	@Override
	public int registrarUsuario(Usuario u) {
		HashMap<String, Object> valores = 
				new HashMap<String, Object>();
		valores.put("nombre", u.getNombre());
		valores.put("email", u.getEmail());
		valores.put("pass", u.getPass());
		valores.put("idCategoriaUsuario",u.getIdCategoriaUsuario());
		
		int idGenerado = simpleInsert.executeAndReturnKey(valores).intValue();
		return idGenerado;
	}

	@Override
	public ArrayList<Usuario> obtenerUsuarios() {
		String sql = ConstantesSQL.SQL_SELECCION_USUARIOS;
		ArrayList<Usuario> usuarios = 
				(ArrayList<Usuario>)
				jdbcTemplate.query(
						sql, new BeanPropertyRowMapper(Usuario.class));
		return usuarios;
	}

	@Override
	public int obtenerIdUsuarioPorEmailYPass(String email, String pass) {
		int id = -1;
		String sql = ConstantesSQL.SQL_SELECCION_ID_POR_EMAIL_PASS;
		String[] valores = {email,pass};
		try {
			id = jdbcTemplate.queryForInt(sql,valores);
		} catch (Exception e) {
			System.out.println("error al obtener id de usuario");
			System.out.println(e.getMessage());
		}
		return id;
	}
	


	@Override
	public void borrarUsuarioPorId(int id) {
		jdbcTemplate.update(ConstantesSQL.SQL_BORRAR_USUARIO,id);
		
	}

	@Override
	public Usuario editarUsuarioPorId(int id) {
		// TODO Auto-generated method stub
		String valores[] = {String.valueOf(id)};
		Usuario usuario = (Usuario) jdbcTemplate.queryForObject(ConstantesSQL.SQL_EDITAR_USUARIO,valores,new BeanPropertyRowMapper(Usuario.class));
		
		return usuario;
	}

	@Override
	public void actualizarUsuario(Usuario u) {
		// TODO Auto-generated method stub
		jdbcTemplate.update(ConstantesSQL.SQL_ACTUALIZAR_USUARIO,u.getNombre(),u.getEmail(),u.getPass(),u.getId());
	}

	@Override
	public List<Usuario> obtenerUsuario(int comienzo, int cuantos) {
		// TODO Auto-generated method stub
		Integer [] valores = {comienzo,cuantos};
		List<Usuario> usuarios = 
				jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_USUARIOS_INICIO_CUANTOS,valores,new BeanPropertyRowMapper(Usuario.class));
		return usuarios;
	}

	@Override
	public int obtenerTotalusuarios() {
		// TODO Auto-generated method stub
		int total = jdbcTemplate.queryForInt(ConstantesSQL.SQL_TOTAL_USUARIOS);
		return total;
	}

	@Override
	public List<Usuario> obtenerUsuario(int comienzo, int cuantos,
			String busqueda) {
		// TODO Auto-generated method stub
		Object [] valores = {"%" + busqueda + "%",Integer.valueOf(comienzo),Integer.valueOf(cuantos)};
		List<Usuario> usuarios = 
				jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_USUARIOS_INICIO_CUANTOS_BUSQUEDA_QUERY,valores,new UsuariosMapper());
		return usuarios;
		
	}

	@Override
	public int obtenerTotalusuarios(String busqueda) {
		// TODO Auto-generated method stub
		int total=jdbcTemplate.queryForInt(ConstantesSQL.SQL_TOTAL_USUARIOS_BUSQUEDA,"%" + busqueda + "%");
		return total;
	}
	

}

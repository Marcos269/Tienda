package daos;

import java.util.ArrayList;
import java.util.List;

import modelo.Usuario;

public interface UsuariosDAO {

	int registrarUsuario(Usuario u);	
	ArrayList<Usuario> obtenerUsuarios();
	int obtenerIdUsuarioPorEmailYPass(String email, String pass);
	void borrarUsuarioPorId(int  id);
	Usuario editarUsuarioPorId(int  id);
	void actualizarUsuario(Usuario u);
	List<Usuario> obtenerUsuario(int comienzo,int cuantos);
	int obtenerTotalusuarios();	
	List<Usuario> obtenerUsuario(int comienzo,int cuantos,String busqueda);
	int obtenerTotalusuarios(String busqueda);	
}

package modelo;

public class Producto {
	private String nombre;
	private double precio;
	private String grupo;
	private String tipo;
	private int id;
	
	public Producto() {
		// TODO Auto-generated constructor stub
	}
	
	public Producto(String nombre, double precio, String grupo, String tipo) {
		super();
		this.nombre = nombre;
		this.precio = precio;
		this.grupo = grupo;
		this.tipo = tipo;
		
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", precio=" + precio + ", grupo="
				+ grupo + ", tipo=" + tipo + ", id=" + id + "]";
	}
	

}
